DELETE FROM conpany;
insert into conpany (cpnno, introduce, cpnname, addtime, regfund, tel, address, scale, business) values ('001', '阿里巴巴集团的使命是让天下没有难做的生意。', '阿里巴巴', '2021-12-29 0:0:0', 100000000, '12345678', '杭州', ' 大', '电商互联网');

insert into conpany (cpnno, introduce, cpnname, addtime, regfund, tel, address, scale, business) values ('002', '开发游戏，QQ。', '腾讯', '2021-12-29 1:0:0', 100000000, '12345679', '深圳', ' 大', '互联网');

insert into conpany (cpnno, introduce, cpnname, addtime, regfund, tel, address, scale, business) values ('003', '搜索引擎。', '百度', '2021-12-29 2:0:0', 100000000, '12345671', '广州', ' 大', '互联网');

insert into conpany (cpnno, introduce, cpnname, addtime, regfund, tel, address, scale, business) values ('004', '电商。', '拼多多', '2021-12-29 4:0:0', 100000000, '12345678', '苏州', ' 大', '电商');

insert into conpany (cpnno, introduce, cpnname, addtime, regfund, tel, address, scale, business) values ('005', '酿酒。', '茅台', '2021-12-29 5:0:0', 100000000, '12345678', '茅台镇', ' 中', '酒');


DELETE FROM positon;
insert into positon (positionno, cpnno, con_cpnname, addtime, positionname, peono, genderrequirement, edubg, wage, workplace, positionintroduce) values ('0001', '001', '阿里巴巴', '2021-12-29 1:0:0','普通职员', '100', 男, '本科', '3000', '杭州', '敲代码');

insert into positon (positionno, cpnno, con_cpnname, addtime, positionname, peono, genderrequirement, edubg, wage, workplace, positionintroduce) values ('0001', '002', '腾讯', '2021-12-29 2:0:0','普通职员', '100', 男, '本科', '3000', '深圳', '敲代码');

insert into positon (positionno, cpnno, con_cpnname, addtime, positionname, peono, genderrequirement, edubg, wage, workplace, positionintroduce) values ('0011', '003', '百度', '2021-12-29 3:0:0','客服', '101', 女, '本科', '3200',  '深圳', '客服');

insert into positon (positionno, cpnno, con_cpnname, addtime, positionname, peono, genderrequirement, edubg, wage, workplace, positionintroduce) values ('0001', '004', '拼多多', '2021-12-29 4:0:0','高管', '66', 男, '本科', '4000',  '北京', '管理');

insert into positon (positionno, cpnno, con_cpnname, addtime, positionname, peono, genderrequirement, edubg, wage, workplace, positionintroduce) values ('0001', '005', '茅台', '2021-12-29 6:0:0','CEO', '89', 男, '本科', '9000',  镇江', '管理');


DELETE FROM graduate ;
insert into graduate (sno, introduce, name, gender, school, entertime, homeaddress, contactway) values ('00001', '本科', '张三', '男', '江苏科技大学', '2020-1-1', '江苏南京', '1121232342');

insert into graduate (sno, introduce, name, gender, school, entertime, homeaddress, contactway) values ('00002', '本科', '李四', '男', '江苏大学', '2020-2-1', '江苏南京', '1121232312');

insert into graduate (sno, introduce, name, gender, school, entertime, homeaddress, contactway) values ('00003', '本科', '唐三', '男', '江苏科技大学', '2020-3-1', '江苏镇江', '1121222342');

insert into graduate (sno, introduce, name, gender, school, entertime, homeaddress, contactway) values ('00004', '本科', '王五', '男', '江苏大学', '2020-4-1', '江苏镇江', '1121213942');

insert into graduate (sno, introduce, name, gender, school, entertime, homeaddress, contactway) values ('00005', '本科', '孙悟空', '男', '北京大学', '2020-5-1', '北京', '1121244542');


DELETE FROM findwork ;
insert into findwork (sno, positionno, applytime) values ('00001', '0001', '2021-6-13');

insert into findwork (sno, positionno, applytime) values ('00002', '0001', '2021-5-13');

insert into findwork (sno, positionno, applytime) values ('00003', '0003', '2021-9-13');

