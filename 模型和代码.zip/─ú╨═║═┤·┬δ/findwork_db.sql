/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2021/12/29 14:14:32                          */
/*==============================================================*/

SET FOREIGN_KEY_CHECKS = 0;  
  
drop table if exists conpany;

drop table if exists findwork;

drop table if exists graduate;

drop table if exists positon;

SET FOREIGN_KEY_CHECKS = 1;
/*==============================================================*/
/* Table: conpany                                               */
/*==============================================================*/
create table conpany
(
   cpnno                varchar(10) not null,
   introduce            varchar(200),
   cpnname              varchar(50),
   addtime              datetime,
   regfund              bigint,
   tel                  varchar(20),
   address              varchar(100),
   scale                varchar(20),
   business             varchar(20),
   primary key (cpnno)
);

/*==============================================================*/
/* Table: findwork                                              */
/*==============================================================*/
create table findwork
(
   sno                  varchar(10) not null,
   positionno           varchar(10) not null,
   applytime            date,
   primary key (sno, positionno)
);

/*==============================================================*/
/* Table: graduate                                              */
/*==============================================================*/
create table graduate
(
   sno                  varchar(10) not null,
   introduce            varchar(200),
   name                 varchar(20),
   gender               varchar(20),
   school               varchar(40),
   entertime            date,
   homeaddress          varchar(100),
   contactway           varchar(20),
   primary key (sno)
);

/*==============================================================*/
/* Table: positon                                               */
/*==============================================================*/
create table positon
(
   positionno           varchar(10) not null,
   cpnno                varchar(10),
   con_cpnname          varchar(50),
   addtime              datetime,
   positionname         varchar(20),
   peono                bigint,
   genderrequirement    varchar(20),
   edubg                varchar(10),
   wage                 bigint,
   workplace            varchar(100),
   positionintroduce    varchar(100),
   primary key (positionno)
);

alter table findwork add constraint FK_findwork foreign key (sno)
      references graduate (sno) on delete restrict on update restrict;

alter table findwork add constraint FK_findwork2 foreign key (positionno)
      references positon (positionno) on delete restrict on update restrict;

alter table positon add constraint FK_have foreign key (cpnno)
      references conpany (cpnno) on delete restrict on update restrict;

